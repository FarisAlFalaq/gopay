<table class="table">
        <tr><td>No Santri</td><td><?php echo $no_santri; ?></td></tr>
        <tr><td>Nama</td><td><?php echo $nama; ?></td></tr>
        <tr><td>Alamat</td><td><?php echo $alamat; ?></td></tr>
        <tr><td>Tempat Lahir</td><td><?php echo $tempat_lahir; ?></td></tr>
        <tr><td>Tanggal Lahir</td><td><?php echo $tanggal_lahir; ?></td></tr>
        <tr><td>No Telp</td><td><?php echo $no_telp; ?></td></tr>
        <tr><td></td><td><a href="<?php echo site_url('santri') ?>" class="btn btn-default">Cancel</a></td></tr>
    </table>